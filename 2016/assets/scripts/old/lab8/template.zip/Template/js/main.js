
var allData = [];

// Variable for the visualization instance
var stationMap;

// Start application by loading the data
loadData();


function loadData() {

  // Hubway XML station feed
  var url = 'https://www.thehubway.com/data/stations/bikeStations.xml';

  // TO-DO: LOAD DATA
}


function createVis() {

  // TO-DO: INSTANTIATE VISUALIZATION

}